# il2cpp tools

Static-analysis scripts for the obfuscated Rec Room IL2CPP client. These are what produced the DTO
wire shapes and the junior-account root cause — see `SHAPES.md` and `JUNIOR.md` in the
`recnet-patcher` repo for the procedures these support.

## Setup

```sh
pip install capstone ijson

# Il2CppDumper (net6-win) against the client, output into ./out/
#   out/dump.cs  out/script.json  out/stringliteral.json  out/il2cpp.h

py mkmethods.py          # once per game build -> methods.pkl
```

Run every script **from this directory**: they read `out/` and `methods.pkl` by relative path.

The GameAssembly.dll path defaults to `C:\Games\recflare-client\GameAssembly.dll`. Override without
editing anything:

```powershell
$env:GAMEASSEMBLY = "C:\path\to\GameAssembly.dll"
```

> ⚠️ **`methods.pkl` is build-specific and is deliberately not shipped.** A stale one is worse than
> none — every address resolves to a plausible but wrong name, silently. Rerun `mkmethods.py` whenever
> `GameAssembly.dll` changes. `mkmethods.py` writes `methods.pkl.txt` stamping which binary it came
> from; the scripts that print a header also echo the DLL's mtime and size so a mismatch is visible.

## Scripts

| Script | Purpose |
| --- | --- |
| `mkmethods.py` | **run first** — builds `methods.pkl` (sorted rva→name) from `out/script.json` |
| `names.py <rva> [len]` | **JSON wire names from a Utf8Json formatter's `.ctor`.** The highest-value tool here; see SHAPES.md |
| `smcalls.py <name-substring>` | a method's direct callees **in call order**, RecRoom code flagged `***`, `Nullable`/`ThrowHelper` flagged `>>>` |
| `nullscan.py <name-regex>` | which methods call `Nullable<T>.get_Value` — narrows an unguarded-nullable bug fast |
| `rangedis.py <start> <end>` | disassemble an arbitrary RVA range, call targets resolved |
| `disfn.py <rva> [len]` | disassemble one method, resolving **string literals** (slow: streams script.json) |
| `whatis.py <rva>...` | address → owning method name |
| `xref.py`, `xref2.py` | find RIP-relative references to an address (e.g. a string literal) |
| `callers.py`, `callsites.py` | who calls a given method |
| `cg.py <rva> [depth]` | call-graph BFS toward `Nullable`/`ThrowHelper` sinks |
| `findm.py` | look up methods by name in `script.json` |
| `disasm.py` | general disassembly helper |
| `gateconfigs.py [base]` | list DTO classes deriving from a base, flagging those with a nullable `DateTime` |

All arguments are **hex without `0x`** (e.g. `py names.py 387BD30 700`).

## Known limits

- **Direct calls only.** These scan `call rel32`. Virtual and interface dispatch
  (`call qword ptr [rax]`) is invisible, which is why a call-graph BFS saturates at depth 3–5 on this
  client. Treat an empty result as "not found by this method", not "does not exist".
- **`disfn.py` has a bug**: it tests `operands[0].type == 1` for call targets, but Capstone's
  `X86_OP_IMM == 2`, so call annotations never print. Its *string* resolution works fine — that's what
  it's for. Use `smcalls.py` or `rangedis.py` when you want calls.
- **Obfuscated names re-roll every game build.** Nothing here is stable across upgrades except
  enum members, compiler-generated names (`<field>5__2`, `<Method>b__0`), and Utf8Json key literals.
- **`gateconfigs.py`** parses `dump.cs` by brace matching — fine for the flat class blocks the dumper
  emits, but it is a text heuristic, not a parser.
