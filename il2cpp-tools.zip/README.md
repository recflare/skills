# il2cpp-tools — wire-shape toolkit

Scripts for recovering endpoint and DTO wire shapes from an obfuscated IL2CPP Rec Room client.
Companion to `SHAPES.md`. Refreshed **2026-08-18** against `recflare-2025` (build `20250718.01`).

> **Read this first if you last used the 2026-08-04 bundle.** That bundle assumed Il2CppDumper
> output (`out/script.json`, `out/dump.cs`, `out/stringliteral.json`) exists. **On the 2025 build it
> cannot be produced** — the shipped `global-metadata.dat` is a 47,962,260-byte decoy of repeated
> `0x52`, `.text`/`il2cpp` are encrypted at rest, `Il2CppCodeRegistration` is field-permuted, and
> Il2CppDumper's PE-loader fallback dies because `GameAssembly.dll` imports Referee. Everything the
> tools need is now produced by the carve pipeline in `carve/` instead. `SHAPES.md` §0/§4/§6 still
> describe the old Il2CppDumper flow and are stale for this build; the technique in §1
> (Utf8Json generated formatters) is unchanged and still the core trick.

## Layout

- **root** — analysis scripts, split into two tiers below.
- **`carve/`** — the pipeline that produces the inputs. Run this first on a new build.

## carve/ — produce the inputs (once per build)

`metadump.exe` is a passive reader (`OpenProcess` + `ReadProcessMemory`); it never writes to the
game or calls into it. Start it **before** launching, then play to the title screen.

```sh
carve/metadump.exe               # -> out/{ga_image.bin, metadata.bin, manifest.txt}
python carve/solve_header.py     # recover the shuffled metadata header
python carve/idtables.py         # identify regions by content ...
python carve/idtables2.py        # ... by cross-referenced counts ...
python carve/idtables3.py        # ... and the remainder
python carve/rebuild_metadata.py # -> out/global-metadata.dat
python carve/rebuild_binary.py   # -> out/GameAssembly.dll  (decrypted code spliced into disk PE)
python carve/mkindex2025.py      # -> methods.pkl + out/stringliteral.json
```

`carve/CARVE.md` has the per-stage findings and why each step is shaped the way it is.
Rebuild `metadump.exe` from `metadump.c` with `cl /O2 metadump.c` in an **amd64** VS shell if you'd
rather not trust the prebuilt binary.

**Build-specific constants are baked into `slots2025.py`, `fields2025.py` and
`carve/mkindex2025.py`** — metadata table offsets, `METADATA_REGISTRATION_RAW`,
`CODEGEN_MODULES_RAW`, `TD_N`, `LOAD_BASE`. A new client changes all of them. `idtables*.py` and
`rebuild_metadata.py` print the new values; copy them across before using the tier-A scripts.

## Configuration

Scripts read these, falling back to the recflare-2025 carve paths:

| var | file |
| --- | --- |
| `GAMEASSEMBLY` | rebuilt `GameAssembly.dll` |
| `GA_IMAGE` | `ga_image.bin` (decrypted memory image) |
| `GA_METADATA` | rebuilt `global-metadata.dat` |

`methods.pkl` and `out/stringliteral.json` are read from the working directory.

## Tier A — works on a carved build (no Il2CppDumper)

| script | purpose |
| --- | --- |
| `names.py <ctor_rva> [len]` | **wire names from a Utf8Json formatter `.ctor`** — the main one |
| `fields2025.py <TypeName>...` | a type's fields with runtime offsets, straight from metadata |
| `slots2025.py <rva> [len]` | all six metadata-usage kinds resolved (types, methods, literals) |
| `mxref.py <slot_rva>...` | who *references* a literal/type slot (rip-relative) |
| `callxref.py <rva>...` | who *calls* a method (direct `E8`/`E9`) |
| `fxref.py <rva>...` | older rip-relative xref; `mxref.py` supersedes it |
| `rangedis.py <a> <b>` | disassemble an RVA range, call targets resolved |
| `callsites.py`, `smcalls.py <name>` | call sites / a method's callees |
| `nullscan.py <regex>` | methods calling `Nullable<T>.get_Value` |
| `cg.py` | call graph — **run `nullscan.py` first**, it consumes `nullable_xref.txt` |
| `whatis2025.py <rva> [--dump <dir>]` | RVA -> name from an RVA-annotated Cpp2IL dump |

`whatis2025.py` defaults to the **2025-04-29** dump. Pass `--dump` for any other build and check the
printed anchor line — `HTTPManager.SendRequest` must be `0x77E0950` on `20250718.01`.

## Tier B — legacy, needs Il2CppDumper `out/`

`callers.py`, `disasm.py`, `disfn.py`, `dtoshape.py`, `findm.py`, `gateconfigs.py`, `mkmethods.py`,
`regall.py`, `regmap.py`, `slots.py`, `whatis.py`, `xref.py`, `xref2.py`.

These read `out/script.json` or `out/dump.cs` and only work on builds Il2CppDumper can process.
`dtoshape.py` is the old one-shot DTO dumper — on a carved build use `names.py` + `fields2025.py`.

## Gotchas that cost real time

- **This client strips `IMAGE_SCN_MEM_EXECUTE`** (code sections are `0xC0000020`; exec is granted at
  runtime). Any tool filtering sections on `MEM_EXECUTE` matches nothing and reports **0 refs for
  every target, silently**. `fxref.py` had exactly this bug — fixed here to filter on `CNT_CODE`.
- **Metadata-usage slots live in `.data` on disk only.** Generated code reaches literals through
  globals initialised to `(kind << 29) | (index * 2 + 1)`; the runtime overwrites them with real
  pointers. Read `.data`/`.rdata` from the **disk** PE, code from `ga_image.bin`.
- **Only `.text` and `il2cpp` may be spliced from memory.** `il2cpp_init` rewrites `.data` in place.
- **Pair formatter keys to members by position and type, not by name.** The obfuscator does not keep
  the `<prop>k__BackingField` convention, so Cpp2IL property names and metadata backing-field names
  disagree. `[DataMember(Name=…)]` attributes landing on the expected index are the cross-check.
- **Enums go on the wire as numbers** unless a by-name formatter exists — and if one did, every
  member name would appear in `stringliteral.json`. Checking a few distinctive member names against
  the literal table settles it in seconds.
- **Resolve a generic call's real type argument from the methodSpec's generic inst**
  (`MetadataRegistration` `_mr[2]/_mr[3]`), not from a nearby `TypeInfo` slot — they can differ.
